Action()
{

	web_url("index.htm", 
		"URL=http://127.0.0.1:1080/WebTours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("returnCookies", 
		"URL=http://external-rules.foxydeal.com/inline/returnCookies", 
		"Method=GET", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://translate.googleapis.com/translate_a/l?client=chrome&hl=en&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&alpha=1", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("seed", 
		"URL=https://clients4.google.com/chrome-variations/seed?osname=win", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("login.pl", 
		"URL=http://127.0.0.1:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/home.html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(31);

	web_submit_form("login.pl_2", 
		"Snapshot=t5.inf", 
		ITEMDATA, 
		"Name=username", "Value=hello", ENDITEM, 
		"Name=password", "Value=123", ENDITEM, 
		"Name=passwordConfirm", "Value=123", ENDITEM, 
		"Name=firstName", "Value=first", ENDITEM, 
		"Name=lastName", "Value=name", ENDITEM, 
		"Name=address1", "Value=street", ENDITEM, 
		"Name=address2", "Value=zip", ENDITEM, 
		"Name=register.x", "Value=45", ENDITEM, 
		"Name=register.y", "Value=13", ENDITEM, 
		LAST);

	web_image("button_next.gif", 
		"Src=/WebTours/images/button_next.gif", 
		"Snapshot=t6.inf", 
		LAST);

	lr_think_time(5);

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t7.inf", 
		LAST);

	web_submit_form("reservations.pl", 
		"Snapshot=t8.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=01/27/2017", ENDITEM, 
		"Name=arrive", "Value=Denver", ENDITEM, 
		"Name=returnDate", "Value=01/28/2017", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_2", 
		"Snapshot=t9.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=000;0;01/27/2017", ENDITEM, 
		"Name=reserveFlights.x", "Value=30", ENDITEM, 
		"Name=reserveFlights.y", "Value=2", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_submit_form("reservations.pl_3", 
		"Snapshot=t10.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=first", ENDITEM, 
		"Name=lastName", "Value=name", ENDITEM, 
		"Name=address1", "Value=street", ENDITEM, 
		"Name=address2", "Value=zip", ENDITEM, 
		"Name=pass1", "Value=first name", ENDITEM, 
		"Name=creditCard", "Value=", ENDITEM, 
		"Name=expDate", "Value=", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_4", 
		"Snapshot=t11.inf", 
		ITEMDATA, 
		"Name=Book Another.x", "Value=54", ENDITEM, 
		"Name=Book Another.y", "Value=8", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_submit_form("reservations.pl_5", 
		"Snapshot=t12.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=01/27/2017", ENDITEM, 
		"Name=arrive", "Value=Denver", ENDITEM, 
		"Name=returnDate", "Value=01/28/2017", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_6", 
		"Snapshot=t13.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=000;0;01/27/2017", ENDITEM, 
		"Name=reserveFlights.x", "Value=47", ENDITEM, 
		"Name=reserveFlights.y", "Value=2", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_7", 
		"Snapshot=t14.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=first", ENDITEM, 
		"Name=lastName", "Value=name", ENDITEM, 
		"Name=address1", "Value=street", ENDITEM, 
		"Name=address2", "Value=zip", ENDITEM, 
		"Name=pass1", "Value=first name", ENDITEM, 
		"Name=creditCard", "Value=", ENDITEM, 
		"Name=expDate", "Value=", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	lr_think_time(6);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Ordinal=1", 
		"Snapshot=t15.inf", 
		LAST);

	return 0;
}